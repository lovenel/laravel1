	<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/




Route::get('/','MainCtr@home');
Route::get('page1','MainCtr@page1');
Route::get('page2','MainCtr@page2');
Route::get('page3','MainCtr@page3');
Route::get('login1','MainCtr@login1');
Route::get('service-store','MainCtr@insertRequest');

Route::get('view-request/{id}','MainCtr@viewRequest');
Route::get('thank-you','MainCtr@thankyou');
Route::post('update-service/{id}','MainCtr@editRequest');



Auth::routes();
