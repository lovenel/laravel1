<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class myModel extends Model
{
    //
}
