<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\ServiceRequest\store;

use App\ServiceRequest as ServiceRequest;

class MainCtr extends Controller{

    public function home(){

     $array = [
     'active' => 1
     ];
     return view('page.home',$array);
   }

   public function page1(){

    $data=ServiceRequest::all();

     $array = [
     'active' => 2
     ];
     return view('page.page1',$array)
     ->with('data', $data);
   }

   public function page2(){

     $array = [
     'active' => 3
     ];
     return view('page.page2',$array);
   }
   public function page3(){

     $array = [
     'active' => 4
     ];
     return view('page.page3',$array);
   }

   public function viewRequest($id){

    $data =ServiceRequest::find($id);
    if(!$id) return 'ID doesnt exist';

    return view('page.home')
      ->with('data', $data);

  }
  public function insertRequest(Request $request){

    $requestedby = $request-> requestedby;
    $office = $request-> office;
    $location = $request-> location;
    $problem = $request-> problem;
    $actionofficer = $request-> actionofficer;
    $category = $request-> category;
    $comment = $request-> comment;
    
    $servRequest = ServiceRequest::store(
      $request -> requestedby,
      $request -> office,
      $request -> location,
      $request -> problem,
      $request -> actionofficer,
      $request -> category,
      $request -> comment
      );
    return redirect('thank-you');

  }

  public function thankyou(){
    return view('page.page2');
  }
  
  public function editRequest($id,Request $request){
  
    $request2=ServiceRequest::find('id',$id)->update([
      'actionofficer'=>$request['actionofficer'],
      'category'=>$request['category'],
      'comment'=>$request['comment']
      ]);
    return $request2->update();

    return redirect('thank-you');
  }
}