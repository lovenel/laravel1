<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiceRequest extends Model
{

	protected $table = 'servicerequest';

	public $fillable =  [
	'requestedby',
	'office',
	'location',
	'problem',
	'category',
	'actionofficer',
	'comment'
	];
	
	public static function store($requestedby,$office,
		$location,$problem,
		$actionofficer,$category,
		$comment){

		$servRequest = ServiceRequest::updateOrCreate(
			['requestedby' => $requestedby , 'office' => $office , 'location' => $location],
			[

			'requestedby' => $requestedby , 'office' => $office , 
			'location' => $location , 'problem' => $problem,
			'actionofficer' => $actionofficer, 'category' => $category, 
			'comment' => $comment
			
			]
			);

		return $servRequest;
	}
}

