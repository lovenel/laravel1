<?php $__env->startSection('title','BGHMC Service Request'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" >
	<div class="row" >
	<br><br><br><br><br><br><br><br><br><br><br>
		<div class="col-sm-offset-1 col-sm-9">
			<div class="panel panel-primary" >              
				<div class="panel-heading">
				<div class="text-center">
					<h3>Your request has been sent. Please wait for a tech support. <br>Thank you for using our online service request. Have a good day!</h3>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>