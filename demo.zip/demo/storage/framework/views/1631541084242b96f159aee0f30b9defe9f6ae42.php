<?php $__env->startSection('title','Page 3'); ?>


<?php $__env->startSection('content'); ?>


<p>page3</p>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>