<?php $__env->startSection('title' ,'BGHMC Service Request'); ?>

<?php $__env->startSection('content'); ?>

//id use for css/javascript
//name use to store values from textbox
<form class="form-horizontal" action="service-store">
	<form type="get" action="service-store">
		<div class="container">			
			<div class="panel panel-primary">              
				<div class="panel-heading">
					<h3>Baguio General Hospital Service Request</h3>
					<div class="panel-body">
						<div class="form-group">
							<label class="control-label col-md-3" for="email">Requested by:</label>
							<div class="col-sm-8">
								<input type="text" maxlength="20" name="requestedby" class="form-control" id="request" placeholder="Enter ID Number or Name" value="<?php if(!empty($data)): ?> <?php echo e($data->requestedby); ?> <?php endif; ?>">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-md-3" for="pwd">Office Name:</label>
							<div class="col-md-8">
								<input type="text" name="office" maxlength="20" class="form-control" placeholder="Enter Office Name" value="<?php if(!empty($data)): ?> <?php echo e($data->office); ?> <?php endif; ?>">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-md-3" for="pwd">Location:</label>
							<div class="col-md-8">
								<input type="text" maxlength="20" name="location" class="form-control" placeholder="Enter Office Location" value="<?php if(!empty($data)): ?> <?php echo e($data->location); ?> <?php endif; ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="comment">Problem: </label><br>
							<label>Note: Include the name of the item</label>
							<textarea maxlength="255" placeholder="e.g. EPSON ink refill black" name="problem" class="form-control" rows="5" > <?php if(!empty($data)): ?> <?php echo e($data->problem); ?> <?php endif; ?>  </textarea>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-10 col-sm-10">
								<button type="submit" class="btn btn-success">Submit</button>
							</div>
						</div>
					</form> 
				</div>
			</div>
			<div class="panel panel-primary">              
				<br><br>
				<div class="panel-heading">
					<h3>Action Officer Panel</h3>
				</div>
				<div class="panel-body">					
					<label><h4>Request Category : </h4></label>
					<div class="row">
						<div class="col-md-6">
							<label><input type="checkbox" name="category" value=""> Laptop</label><br>
							<label><input type="checkbox" name="category" value=""> HOMIS Program</label>
							<label><input type="checkbox" name="category" value=""> User Account Management</label>
							<label><input type="checkbox" name="category" value=""> Installation of Telephone(Intercom)</label><br>
							<label><input type="checkbox" name="category" value=""> Ink Refill</label><br>
							<label><input type="checkbox" name="category" value=""> Service Unit(Computer Unit, Printer, <br>Computer accessories)</label>
						</div>
						<div class="col-md-6">
							<label><input type="checkbox"  name="category" value=""> LCD Projector</label> <br>
							<label><input type="checkbox" name="category" value=""> Installation of Network</label><br>
							<label><input type="checkbox" name="category" value=""> Hardware Technical Assistance</label><br>
							<label><input type="checkbox" name="category" value=""> Software Technical Assistance</label><br>
							<label><input type="checkbox" name="category" value=""> HOMIS Orientation/Training/Lecture</label><br>
							<label><input type="checkbox" name="category" value=""> Hardware Technical Assistance</label><br>
							<label><input type="checkbox" name="category" value=""> Others</label><br>
						</div>
					</div>
					<div class="form-group">
						<br>
						<input type="text" class="form-control" name="actionofficer" placeholder="Action Officer"><br>
						<label for="comment">Action Officer Diagnosis: </label><br>
						<textarea placeholder="Additional Information/Comment" class="form-control" rows="5" name="comment"></textarea>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-10 col-sm-10">
							<button type="submit" class="btn btn-success">Submit</button>
						</div>
					</div>
				</div>	
			</div>
		</form>
	</div>
</div>
</div>

</form>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/home.js')); ?>"  ></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>