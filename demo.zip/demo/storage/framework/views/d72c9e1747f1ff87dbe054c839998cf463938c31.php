<?php $__env->startSection('title','BGHMC Service Request'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="panel panel-danger">
			<div class="panel panel-primary">              
				<div class="panel-heading">
					<h3>Admin Monitoring</h3>
				</div>
			</div>
			<div class="panel-body">
				<button class="btn btn-info ">View All</button>
				<button class="btn btn-warning ">View Pending</button>
				<button class="btn btn-success ">View Completed</button>
				<table class="table">
					<thead>
						<tr>
							<th>Date</th>
							<th>Office</th>
							<th>Location</th>
							<th>Problem</th>
							<th>Requested by</th>
						</tr>
					</thead>
					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $D): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($D->created_at); ?></td>
						<td><?php echo e($D->office); ?></td>
						<td><?php echo e($D->location); ?></td>
						<td><?php echo e($D->problem); ?></td>
						<td><?php echo e($D->requestedby); ?></td>

						<td>
							<a href="/update-service/<?php echo e($D->id); ?>" class="btn btn-default btn-sm">
								Edit
							</a>
						</td>	

					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</table>
			</div>
			<div class="panel-footer"></div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>