<?php $__env->startSection('title','Page 2'); ?>

<?php $__env->startSection('content'); ?>


<p>page2</p>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>