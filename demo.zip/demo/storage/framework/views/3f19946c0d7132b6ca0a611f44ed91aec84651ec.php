<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <title>Baguio General Hospital Service Request</title>

       
    </head>
    <body>
        <div class="col-md-6 col-md-offset-3">
        	<div class="panel panel-primary">
        		<div class="panel-heading">
        			<h3>Registration Form</h3>
        		</div>
        		<div class="panel-body">
                <?php if(Session::has('info')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('info')); ?>

                        <?php endif; ?>
                    </div>
        			<form action="<?php echo e(route('register_check')); ?>" method="POST">
        				<div class="form-group <?php echo e($errors->has('username')?'has-error':''); ?>">
        					<label>Username</label>
        					<input type="text" name="username" class="form-control">
        					<?php if($errors->has('username')): ?>
        						<span class="help-block"><?php echo e($errors->first('username')); ?></span>
        					<?php endif; ?>
        				</div>
        				<div class="form-group <?php echo e($errors->has('email')?'has-error':''); ?>">
        					<label>Email</label>
        					<input type="email" name="email" class="form-control">
        					<?php if($errors->has('email')): ?>
        						<span class="help-block"><?php echo e($errors->first('email')); ?></span>
        					<?php endif; ?>
        				</div>
        				<div class="form-group <?php echo e($errors->has('password')?'has-error':''); ?>">
        					<label>Password</label>
        					<input type="password" name="password" class="form-control">
        					<?php if($errors->has('password')): ?>
        						<span class="help-block"><?php echo e($errors->first('password')); ?></span>
        					<?php endif; ?>
        				</div>
        				<div class="form-group <?php echo e($errors->has('repeat_password')?'has-error':''); ?>">
        					<label>Repeat Password</label>
        					<input type="password" name="repeat_password" class="form-control">
        					<?php if($errors->has('repeat_password')): ?>
        					<span class="help-block"><?php echo e($errors->first('repeat_password')); ?></span>
        				<?php endif; ?>
        				</div>
        				<button type="submit" class="btn btn-primary">Submit</button>
        				<?php echo e(csrf_field()); ?>

        			
        		</div>
        	</div>
        </div>
    </body>
</html>
