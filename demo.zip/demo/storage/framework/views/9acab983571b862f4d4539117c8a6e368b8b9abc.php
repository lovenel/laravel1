<?php $__env->startSection('title','BGHMC Service Request'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="panel panel-danger">
			<div class="panel panel-primary">              
				<div class="panel-heading">
					<h3>Admin Monitoring</h3>
				</div>
			</div>
			<div class="panel-body">
				<button class="btn btn-success btn-xs">Accept</button>
				<button class="btn btn-success btn-xs" data-toggle="modal" data-target="#viewAll">View All</button>
				<button class="btn btn-success btn-xs">View Pending</button>
				<button class="btn btn-success btn-xs">View Completed</button>
				<table class="table">
					<thead>
						<tr>
							<th>Date</th>
							<th>Office</th>
							<th>Location</th>
							<th>Phone</th>
							<th>Requested by</th>
						</tr>
					</thead>
				</table>
			</div>
			<div class="panel-footer"></div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>