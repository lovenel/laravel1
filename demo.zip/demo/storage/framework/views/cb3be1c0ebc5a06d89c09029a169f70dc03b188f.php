<?php $__env->startSection('title' ,'BGHMC Service Request'); ?>


<?php $__env->startSection('content'); ?>


//id use for css/javascript
//name use to store values from textbox
<div class="col-md-6 col-md-offset-3">
	<div class="panel panel-primary">              
		<div class="panel-heading">
			<h3>Baguio General Hospital Service Request</h3>
			<div class="panel-body">
				<form class="form-horizontal" action="service-store">
					<div class="form-group">
						<form type="get" action="service-store">
							<label class="control-label col-md-3" for="email">Requested by:</label>
							<div class="col-sm-8">
								<input type="text" name="requestedby" class="form-control" id="request" placeholder="Enter ID Number or Name">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-md-3" for="pwd">Office Name:</label>
							<div class="col-md-8">
								<input type="text" name="office" class="form-control" placeholder="Enter Office Name">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-md-3" for="pwd">Location:</label>
							<div class="col-md-8">
								<input type="text" name="location" class="form-control" placeholder="Enter Office Location">
							</div>
						</div>
						<div class="form-group">
							<label for="comment">Problem: </label><br>
							<label>Note: Include the name of the item</label>
							<textarea placeholder="e.g. EPSON ink refill black" name="problem" class="form-control" rows="5" ></textarea>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-2 col-sm-10">
								<button type="submit" class="btn btn-default">Submit</button>
							</form>
						</div>
					</div>
				</form> 
			</div>
		</div>
	</div>
</div>
</div>

<div class="col-md-6 col-md-offset-3">
	<div class="panel panel-primary">              
		<div class="panel-heading">
			<h3>Action Officer Panel</h3>
		</div>
		<div class="panel-body">
			<label>Request Category</label>
			<div class="checkbox">
				<label><input type="checkbox" name="" value="">Laptop</label> <label><input type="checkbox" name="" value="">LCD Projector</label> <br>
				<label><input type="checkbox" name="" value="">HOMIS Program</label> <label><input type="checkbox" name="" value="">Installation of Network</label><br>
				<label><input type="checkbox" name="" value="">User Account Management</label> <label><input type="checkbox" name="" value="">Hardware Technical Assistance</label><br>
				<label><input type="checkbox" name="" value="">Installation of Telephone(Intercom)</label><br>
				<label><input type="checkbox" name="" value="">Ink Refill</label><br>
				<label><input type="checkbox" name="" value="">Service Unit(Computer Unit, Printer, <br>Computer accessories)</label>

			</div>

			<div class="input-group">
				<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
				<input id="email" type="text" class="form-control" name="email" placeholder="Action Officer">
			</div>
			<div class="input-group">
				<span class="input-group-addon">Text</span>
				<input id="msg" type="text" class="form-control" name="msg" placeholder="Additional Info">
			</div>

			<div class="form-group">
				<label for="comment">Problem: </label><br>
				<label>Note: Include the name of the item</label>
				<textarea placeholder="e.g. EPSON ink refill" class="form-control" rows="5" id="comment"></textarea>
			</div>
			<button type="submit" class="btn btn-primary">SUBMIT</button>
		</form>
	</div>
</div>
</div>  
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/home.js')); ?>"  ></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>