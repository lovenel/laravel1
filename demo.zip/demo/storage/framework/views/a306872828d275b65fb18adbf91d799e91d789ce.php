<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
  <title> <?php echo $__env->yieldContent('title'); ?> </title>

</head>
<body>

    <div class="container">

      <?php echo $__env->yieldContent('content'); ?>

    </div>    



<script type="text/javascript" src="<?php echo e(asset('jquery/jquery-3.2.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"  ></script>

 <?php echo $__env->yieldContent('script'); ?> 


</body>
</html>
