	
 
$( function () {
	autoSetDateNow();	
});



function autoSetDateNow() {
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();

	if(dd<10) {
		dd='0'+dd
	} 

	if(mm<10) {
		mm='0'+mm
	} 

	today = mm+'/'+dd+'/'+yyyy;
	document.getElementById('demo').value= today;
	//////////////
	var currentTime = new Date(),
	hours = currentTime.getHours(),
	minutes = currentTime.getMinutes();

	if (minutes < 10) {
		minutes = "0" + minutes;
	}

	var suffix = "AM";
	if (hours >= 12) {
		suffix = "PM";
		hours = hours - 12;
	}
	if (hours == 0) {
		hours = 12;
	}
	time1=hours+":"+minutes+" "+suffix;

	document.getElementById('time').value=time1;
/////////////////////////////////////////////////////////////////
}