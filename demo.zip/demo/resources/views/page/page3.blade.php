
@extends('master.master')

@section('title','Page 3')


@section('content')


<p>page3</p>

@endsection


