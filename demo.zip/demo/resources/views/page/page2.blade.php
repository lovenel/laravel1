@extends('master.master')	

@section('title','BGHMC Service Request')

@section('content')
<div class="container" >
	<div class="row" >
		<br><br><br><br><br><br><br><br><br><br>
		<div class="col-sm-offset-1 col-sm-9">
			<div class="panel panel-primary" >              
				<div class="panel-heading">
					<div class="text-center">
						<br>
						<div class="alert alert-success">
							<h3>Your request has been sent. Please wait for a tech support. <br>Thank you for using our online service request.</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>s
@endsection