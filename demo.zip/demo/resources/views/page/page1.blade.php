
@extends('master.master')

@section('title','BGHMC Service Request')

@section('content')
<div class="container">
	<div class="row">
		<div class="panel panel-danger">
			<div class="panel panel-primary">              
				<div class="panel-heading">
					<h3>Admin Monitoring</h3>
				</div>
			</div>
			<div class="panel-body">
				<button class="btn btn-info ">View All</button>
				<button class="btn btn-warning ">View Pending</button>
				<button class="btn btn-success ">View Completed</button>
				<table class="table">
					<thead>
						<tr>
							<th>Date</th>
							<th>Office</th>
							<th>Location</th>
							<th>Problem</th>
							<th>Requested by</th>
						</tr>
					</thead>
					@foreach($data as $D)
					<tr>
						<td>{{$D->created_at}}</td>
						<td>{{$D->office}}</td>
						<td>{{$D->location}}</td>
						<td>{{$D->problem}}</td>
						<td>{{$D->requestedby}}</td>

						<td>
							<a href="/view-request/{{$D->id}}" class="btn btn-default btn-sm">
								Edit
							</a>
						</td>	

					</tr>
					@endforeach
				</table>
			</div>
			<div class="panel-footer"></div>
		</div>
	</div>
</div>
@endsection
