
@extends('master.master')

@section('title' ,'Login')


@section('content')
<p>Login</p>

@endsection


