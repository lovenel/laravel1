
@extends('master.master')

@section('title' ,'Login')


@section('content')
<p>Login1</p>

@endsection


